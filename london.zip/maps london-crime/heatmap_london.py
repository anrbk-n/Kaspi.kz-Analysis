import pandas as pd
import folium
from folium.plugins import HeatMap
import ast

# read london crime data from csv file
crime_data = pd.read_csv('/Users/nurassylkaiyrzhan/Desktop/proga/london_crime.csv', sep=',', header=0)

# extract latitude and longitude from the 'location' field
crime_data['latitude'] = crime_data['location'].apply(lambda x: float(ast.literal_eval(x)['latitude']))
crime_data['longitude'] = crime_data['location'].apply(lambda x: float(ast.literal_eval(x)['longitude']))
crime_data.dropna(subset=['latitude', 'longitude'], inplace=True)  # remove rows without coordinates

# take a random sample of n records for the heatmap
crime_data_sample = crime_data.sample(n=100000)

# initialize map centered on london
m = folium.Map(location=[51.5074, -0.1278], zoom_start=12)

# prepare data for heatmap
heat_data = [[row['latitude'], row['longitude']] for _, row in crime_data_sample.iterrows()]
HeatMap(heat_data, radius=15, blur=10, max_zoom=1).add_to(m)  # add heatmap to map

# create a legend for heatmap intensity
legend_html = f"""
<div style="position: fixed; 
             top: 10px; left: 10px; width: 250px; height: auto; 
             border:2px solid grey; z-index:9999; font-size:14px; 
             background-color: white;">
&nbsp; <b>Heatmap of Crimes n={len(crime_data_sample)}</b><br>
&nbsp; <i style='background-color: rgba(0, 0, 255, 0.7); width: 18px; height: 18px; display: inline-block;'></i>&nbsp; Low intensity<br>
&nbsp; <i style='background-color: rgba(0, 255, 0, 0.7); width: 18px; height: 18px; display: inline-block;'></i>&nbsp; Medium intensity<br>
&nbsp; <i style='background-color: rgba(255, 0, 0, 0.7); width: 18px; height: 18px; display: inline-block;'></i>&nbsp; High intensity<br>
</div>
"""
m.get_root().html.add_child(folium.Element(legend_html))  # add legend to map

# save map to file
m.save('/Users/nurassylkaiyrzhan/Desktop/proga/london_crime_heatmap.html')
print('Map created and saved to file: london_crime_heatmap.html')
