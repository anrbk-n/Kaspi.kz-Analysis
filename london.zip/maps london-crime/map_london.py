import pandas as pd
import folium
import ast

# read london crime data from csv file
crime_data = pd.read_csv('/Users/nurassylkaiyrzhan/Desktop/proga/london_crime.csv', sep=',', header=0)

# extract latitude and longitude from the 'location' field
crime_data['latitude'] = crime_data['location'].apply(lambda x: float(ast.literal_eval(x)['latitude']))
crime_data['longitude'] = crime_data['location'].apply(lambda x: float(ast.literal_eval(x)['longitude']))
crime_data.dropna(subset=['latitude', 'longitude'], inplace=True)  # remove rows without coordinates

# take a random sample of n records for the map
crime_data_sample = crime_data.sample(n=500)

# set colors for different crime categories
category_colors = {
    'anti-social-behaviour': 'blue',
    'violent-crime': 'red',
    'burglary': 'green',
    'criminal-damage-and-arson': 'orange',
    'drugs': 'purple',
    'other-theft': 'pink',
    'robbery': 'darkblue',
    'theft-from-the-person': 'lightblue',
    'vehicle-crime': 'lightgreen',
    'public-order': 'beige',
    'possession-of-weapons': 'gray',
    'shoplifting': 'lightgreen',
    'other-crime': 'lightgray'
}

# initialize map centered on london
m = folium.Map(location=[51.5074, -0.1278], zoom_start=12)

# count markers per crime category
marker_counts = {category: 0 for category in category_colors.keys()}

# add markers for each crime in the sample
for _, row in crime_data_sample.iterrows():
    location_data = ast.literal_eval(row['location'])
    street_name = location_data['street']['name']

    color = category_colors.get(row['category'], 'black')  # set marker color by crime category

    # create a popup with crime details
    popup_text = f"""
    <div style="font-family: Arial; font-size: 14px;">
        <b>Crime Category:</b> {row['category'].replace('-', ' ').title()}<br>
        <b>Street:</b> {street_name}
    </div>
    """

    # add marker to the map
    folium.Marker(
        location=[row['latitude'], row['longitude']],
        popup=popup_text,
        icon=folium.Icon(color=color)
    ).add_to(m)

    if row['category'] in marker_counts:
        marker_counts[row['category']] += 1  # increment count for each category

# create a legend for crime categories
legend_html = f"""
<div style="position: fixed; 
             top: 10px; left: 10px; width: 300px; height: auto; 
             border:2px solid grey; z-index:9999; font-size:14px; 
             background-color: white;">
&nbsp; <b>Crime Categories n={len(crime_data_sample)} </b><br>"""

for category, count in marker_counts.items():
    color = category_colors.get(category, 'black')
    legend_html += f"&nbsp;<i style='background-color:{color};width:10px;height:10px;display:inline-block;'></i>&nbsp; {category.replace('-', ' ').title()}: {count} markers<br>"

legend_html += "</div>"

# add legend to the map
m.get_root().html.add_child(folium.Element(legend_html))

# save map to file
m.save('/Users/nurassylkaiyrzhan/Desktop/proga/london_crime_map.html')
print('Map created and saved to file: london_crime_map.html')
